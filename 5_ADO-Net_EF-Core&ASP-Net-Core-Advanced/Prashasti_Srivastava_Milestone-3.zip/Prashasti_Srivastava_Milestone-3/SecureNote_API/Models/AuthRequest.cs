﻿namespace SecureNote_API.Models {
    public class AuthRequest {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}